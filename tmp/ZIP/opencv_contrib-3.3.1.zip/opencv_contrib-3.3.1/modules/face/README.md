Face recognition techniques
===========================

Collection of face recognition techniques:

1. Eigen Faces
2. Fisher Faces
3. Local Binary Pattern Histograms
