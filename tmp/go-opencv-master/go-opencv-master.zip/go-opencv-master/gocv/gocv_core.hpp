#include <opencv2/opencv.hpp>
#include <vector>
#include <iostream>

cv::Mat Mat64ToGcvMat_(int row, int col, std::vector<double> data);
