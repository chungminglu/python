package opencv

import (
	"testing"
)

func TestLoadImage(t *testing.T) {
	// t.Errorf("aaa")
}
